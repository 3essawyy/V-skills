---
name: convert-lecture-pdf2md-v2
description: Convert lecture-slide PDFs to token-lean Markdown without losing meaning that lives in figures, plots, matrices and equations. Extracts text deterministically, sends only informative figures to a cheap vision model, then injects and validates. Use when asked to convert lecture/slide PDFs to md, or to make slides readable for later sessions.
---

# convert-lecture-pdf2md-v2

Goal: **A) few tokens, B) no context lost in pictures.** Text is extracted by script (free). Vision is paid only for figures that carry meaning, one call per slide figure (fragments are merged into a composite crop).

`<skill_dir>` = the folder containing this SKILL.md. Run scripts from there by absolute path; the script has no install-path dependency (works the same under Claude Code and Gemini CLI). Needs `pip install pymupdf pillow` (use the project/user venv, not global).

## Output layout (default)
PDF in `.../original/X.pdf` -> `.../converted/X.md`, `converted/media/X/<id>.png|.md`, `converted/media/X.manifest.json`. Override with `--out-dir`. Never write into `original/`.

## Stage 1 - extract (script, no LLM)
```
python <skill_dir>/scripts/convert_pdf.py "<pdf>" [--out-dir <dir>]
```
Prints the fidelity report. Check: slides == sections, figures count sane. Decorative/tiny/repeated art is dropped automatically; text-free slides with no detected figure are sent whole to vision.

## Stage 2 - vision transcription (cheap model, batched)
Read `media/<stem>.manifest.json`. For each `batches.batch_N` (8 figures), spawn ONE subagent on the cheap vision model (Claude: Haiku; Gemini: Flash) so image tokens stay out of the main context. If the CLI has no subagents, do the batches in the main session. Figures with `"hard": true` use the strong model (Claude: Sonnet; Gemini: Pro).

Subagent prompt (fill in paths):
> You transcribe lecture-slide figures to text for a study markdown. Manifest: `<manifest>`; do batch `<batch_N>`. Image paths in the manifest are relative to `<out_dir>`. For each figure: view the PNG, then write `<out_dir>/<companion>` (exact path in the manifest). Use `slide_title`, `context_before/after` and `labels` (text already extracted from the figure) as hints; do not re-OCR labels you can reuse, but fix them if wrong. Describe what the slide uses the figure for. Output only the content, no preamble, by type:
> - **flowchart / state / network diagram** -> a ```mermaid block (valid header, e.g. `flowchart LR`), plus one line on the takeaway.
> - **equation / matrix** -> `$$ ... $$` LaTeX (balanced).
> - **plot / histogram / chart / feature space** -> plain text: axes (name, range/ticks), each series/curve/class, key values, shape/trend, and the point the slide makes. No Mermaid.
> - **photo / screenshot / illustration** -> 1-2 sentences, then anything the slide's text depends on.
> - **purely decorative** -> the single word `skip`.
> Be faithful: transcribe, do not explain beyond the slide. Never restate text that is already in `context_before/after` or the slide's bullets (no "Bullet above it", no repeated captions), and do not add "Point:"/"Takeaway:" lines unless the slide shows a conclusion that is NOT in its text; never add textbook inferences. Read legends (colour/marker -> class) and formulas in the crop; do not write "(unclear)" for something a legend or label in the image answers. If unsure of a value write `(unclear)` instead of guessing. Keep each file under ~120 words unless a diagram needs more.
> Reply with only: batch name and a count of files written.

Resumable: files already written are not redone (skip ids whose companion exists).

## Stage 3 - inject, validate, report (script, no LLM)
```
python <skill_dir>/scripts/convert_pdf.py "<pdf>" [--out-dir <dir>] --inject
```
Merges each companion under a marker `**[Figure <id> - AI transcription]**` (provenance stays visible; slide text and AI text are never blended), keeps one image link for ground-truth recheck, removes `skip` figures, rejects invalid Mermaid/LaTeX and leaves them pending. Re-run `--report` any time. Re-run Stage 2 only for ids still listed as pending/invalid.

## QA before trusting a deck
Sample 5-10 figure slides, compare md vs the PDF page (Sonnet-level reviewer or yourself). If a systematic error shows (e.g. wrong axes), fix the prompt and redo that batch.

## Model guide
| Step | Model |
|---|---|
| Extract, inject, report | none (script) |
| Vision, normal figures | cheap vision (Haiku / Flash) |
| Vision, `hard` (dense math, large graphs) | strong (Sonnet / Pro) |
| Spot-check QA, orchestration | session model |

## Knobs (top of `convert_pdf.py`)
`MIN_FIG_AREA_FRAC`, `REPEAT_FRAC` (decor filters), `MAX_PX` (crop size sent to vision), `BATCH_SIZE`, `LOWTEXT_CHARS`.

Project rule (CMPS450): `converted/` holds faithful conversions only; AI figure descriptions live there but always inside the marked block above.
